Group members’ names and x500s: Horoom Bula - Bula0023, Ararso Goshe - Goshe011
Contributions of each partner: We both split if evenly to work together to get our code to work
How to compile and run your program: You run the program and pick a difficulty by picking a number 1-3.
Then you pick an 2 integers in bound of the minefield for your starting x and y coordinates. You then pick coordinates that are in bound but
you also get to decide if you put down a flag or not by writing true or false. You win the game once you reveal every cell without
a mine.
Assumptions:When you pick your starting coordinates just put the number then enter. For the flag you just put true or false.

Additional features: We put no additional features.

• Any outside sources (aside from course resources) consulted for ideas used in the project, in
the format: No one but TA

I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.

Horoom Bula and Ararso Goshe